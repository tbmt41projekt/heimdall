addpath('./matlabPyrTools');
addpath('./matlabPyrTools/MEX');
